import 'whatwg-fetch';
import "babel-polyfill";
