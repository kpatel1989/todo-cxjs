export const EndPoints = {
     appointments : "https://z0m90ymu94.execute-api.us-east-1.amazonaws.com/dev/api/appointments"
}